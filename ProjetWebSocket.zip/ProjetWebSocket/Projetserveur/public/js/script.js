
const htmlSocket = new WebSocket(
  "ws://localhost:3000"
);

function voirrgb(id)
{
    
    choixrgb = document.getElementById('rgb');
    nbled=document.getElementById('nbledform');
    nbled.value=id;
    visible=choixrgb.style.display;
    
    
    if (visible == 'none')
    {
        choixrgb.style.display = 'block';
        
    }
    else{
        choixrgb.style.display='none';
    }
        
    
}
function changercouleur(couleur)
{
    test=document.getElementById('test');
    test.style.color=couleur;
}



function senddata(ledrouge,ledverte,ledbleu)
{
    
    var valledrouge=document.getElementById(ledrouge).value;
    console.log(valledrouge);

    var valledverte=document.getElementById(ledverte).value;
    console.log(valledverte);

    var valledbleu=document.getElementById(ledbleu).value;
    console.log(valledbleu);

    const exampleSocket = new WebSocket(
        "wss://www.example.com/socketserver",
        "protocolOne"
      );
      

    const msg = {
        type: "web",
        red: valledrouge,
        green: valledverte,
        blue: valledbleu,
        id: clientID,
        
      };
    
      // Send the msg object as a JSON-formatted string.
      exampleSocket.send(JSON.stringify(msg));


      exampleSocket.onmessage = function(event) {
        
        var text = "";
        var msg = JSON.parse(event.data);
        var time = new Date(msg.date);
        var timeStr = time.toLocaleTimeString();
      
        switch(msg.type) {
          
          case "red":
            text = "<b>User <em>" + msg.name + "</em> signed in at " + timeStr + "</b><br>";
            break;
          case "message":
            text = "(" + timeStr + ") <b>" + msg.name + "</b>: " + msg.text + "<br>";
            break;
          case "rejectusername":
            text = "<b>Your username has been set to <em>" + msg.name + "</em> because the name you chose is in use.</b><br>"
            break;
          case "userlist":
            var ul = "";
            for (i=0; i < msg.users.length; i++) {
              ul += msg.users[i] + "<br>";
            }
            document.getElementById("userlistbox").innerHTML = ul;
            break;
        }
      
        if (text.length) {
          f.write(text);
          document.getElementById("chatbox").contentWindow.scrollByPages(1);
        }
      };


    
}



function askvaluebouton()
{
    
    req="http://127.0.0.1:8102/value"
    console.log("askvaluebutton");
    const xhr = new XMLHttpRequest();
    xhr.open("GET", req);
    xhr.send();
    xhr.responseType = "text";
    xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
        console.log("on veut la réponse stp");
        console.log(xhr.responseText);
        document.getElementById(1).value = xhr.responseText;
    } else {
        console.log(`Error: ${xhr.status}`);
    }
    };
    

}


function sendGetRequest(getRequest)
{
    const xhr = new XMLHttpRequest();
    const req = getRequest;
    xhr.open("GET", req);
    xhr.send();
    xhr.responseType = "";
    xhr.onload = () => {
    if (xhr.readyState == 4 && xhr.status == 200) {
        const data = xhr.responseText;
    } else {
        console.log(`Error: ${xhr.status}`);
    }
    };
}


function startjeu()
{
  
  console.log("1");
  const msg = {
    type: "start"
    
  };

  /*htmlSocket.onopen = () => */
  htmlSocket.send(JSON.stringify(msg)); 
  // waiting for the socket connection to be opened to send the msg object as a JSON-formatted string.
  console.log("2");
  htmlSocket.onmessage = function(event) {
    console.log("jeu commencé");
    document.getElementById('affichagestart').innerHTML = "Jeu commencé";

}
}

function getesp(){

  
  const msg = {
    type: "getespco"
    
  };

  /*htmlSocket.onopen = () => */
  htmlSocket.send(JSON.stringify(msg)); 
  // waiting for the socket connection to be opened to send the msg object as a JSON-formatted string.
  
  htmlSocket.onmessage = function(event) {
    response=event.data;
    
    /*
    liste=list(response)
    liste.remove('"')
    liste.remove(',')
    liste.remove('[')
    liste.remove(']')
    print(liste)*/
    function function1() {
      var ul = document.getElementById("list");
      var li = document.createElement("li");
      li.appendChild(document.createTextNode("Element 4"));
    }

    document.getElementById('affichageespco').innerHTML += "\n";
    response = response.replaceAll('[', '')
    response = response.replaceAll(']', '')
    response = response.replaceAll('"', '')
    response = response.replaceAll(',', '')
    for (let i = 0; i < response.length; i++){
      console.log(response[i]);
      document.getElementById('affichageespco').innerHTML += response[i];
      document.getElementById('affichageespco').innerHTML += "\n";
      
    }
    
    
    
    
}
}





var receive=function(msg)
{ 
    var li=document.createElement('li');
    li.innerHTML=msg;
    document.getElementById('esp').appendChild('li');
  
  
}
/*
htmlSocket.onmessage = function(event) {
  var text = "";
  var msg = JSON.parse(event.data);

  switch(msg.type) {
    case "esp":
      msg.list.length
      
      break;
    case "username":
      text = "<b>User <em>" + msg.name + "</em> signed in at " + timeStr + "</b><br>";
      break;
    case "message":
      text = "(" + timeStr + ") <b>" + msg.name + "</b>: " + msg.text + "<br>";
      break;
    case "rejectusername":
      text = "<b>Your username has been set to <em>" + msg.name + "</em> because the name you chose is in use.</b><br>"
      break;
    case "userlist":
      var ul = "";
      for (i=0; i < msg.users.length; i++) {
        ul += msg.users[i] + "<br>";
      }
      document.getElementById("userlistbox").innerHTML = ul;
      break;
  }

  if (text.length) {
    f.write(text);
    document.getElementById("chatbox").contentWindow.scrollByPages(1);
  }
};

*/
  